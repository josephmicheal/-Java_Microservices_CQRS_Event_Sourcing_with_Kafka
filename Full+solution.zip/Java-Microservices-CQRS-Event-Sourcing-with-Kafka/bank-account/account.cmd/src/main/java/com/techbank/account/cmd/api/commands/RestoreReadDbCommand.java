package com.techbank.account.cmd.api.commands;

import com.techbank.cqrs.core.commands.BaseCommand;

public class RestoreReadDbCommand extends BaseCommand {
}
