package com.techbank.account.query.api.queries;

import com.techbank.cqrs.core.queries.BaseQuery;

public class FindAllAccountsQuery extends BaseQuery {
}
