package com.techbank.account.query.api.dto;

public enum EqualityType {
    GREATER_THAN, LESS_THAN
}
