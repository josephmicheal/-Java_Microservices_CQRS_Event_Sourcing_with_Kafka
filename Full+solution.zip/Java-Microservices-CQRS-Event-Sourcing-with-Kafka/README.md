# Java-Microservices-CQRS-Event-Sourcing-with-Kafka
Spring Boot Microservices that comply to the CQRS &amp; Event Sourcing patterns, powered by Java and Apache Kafka
