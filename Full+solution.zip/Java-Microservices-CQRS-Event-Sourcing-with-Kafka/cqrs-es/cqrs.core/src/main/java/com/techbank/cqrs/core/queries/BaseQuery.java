package com.techbank.cqrs.core.queries;

public abstract class BaseQuery {
}
